<?php

header("Content-type: application/json");

////////////////////////

if($_GET['type'] == "search"){

if($_GET['name']){

$CVTY = $_GET['name'];

$ch = curl_init();
$url = "https://mobomovies.fun/s/" . urlencode($CVTY);
// تنظیم آدرس اینترنتی هدف
curl_setopt($ch, CURLOPT_URL, $url);
// تنظیم نتیجه در قالب یک رشته
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_REFERER, "https://google.com");
curl_setopt($ch, CURLOPT_TIMEOUT, 6000);
$set = json_encode(curl_exec($ch), 1000);
curl_close($ch);

$ajax = json_decode($set);

preg_match_all('#<img class="thumb" src="(.*)" alt="(.*)" loading="(.*)">#', $ajax, $poster); ///$poster[1];
preg_match_all('#<a title="(.*)" href="(.*)" class="btn rounded-1 mr-auto mt-6 w-max">(.*)</a>#', $ajax, $url);
$title = $poster[2];

for($i = 0; $i < count($poster[1]); $i++){
	$data = ['name'=>$title[$i], 'poster'=>"https://mobomovies.fun" . $poster[1][$i], 'page'=>"https://mobomovies.fun" . $url[2][$i], 'download_link'=>"https://api-man.robotapi.xyz/api/moviefun/?type=download&url=https://mobomovies.fun" . $url[2][$i]];
	$arry[] = $data;
	}
	
$rwtie = ['ok'=>true, 'writer'=>"aminrngbr", 'channel'=>"@sourcetalar", 'result'=>$arry];

	
echo json_encode($rwtie, 1000);

}else{

echo Null;

}

}

////////////////////////

if($_GET['type'] == "download"){
	
if($_GET['url']){
	
$CVTY = $_GET['url'];

$ch = curl_init();
$url = "{$CVTY}";
// تنظیم آدرس اینترنتی هدف
curl_setopt($ch, CURLOPT_URL, $url);
// تنظیم نتیجه در قالب یک رشته
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.1");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_REFERER, "https://google.com");
curl_setopt($ch, CURLOPT_TIMEOUT, 6000);
$set = json_encode(curl_exec($ch), 1000);
curl_close($ch);

@$ajax = json_decode($set);

preg_match_all('#<a target="_blank nofollow" href="(.*)" class="btn dl-btn">#', $ajax, $link);

@$get = "https://mobomovies.fun" . $link[1][0];

getdwo($get);
	
	}
	
	}
	
function getdwo($get){
	
@$chos = json_encode(file_get_contents($get));

@$bexyy = json_decode($chos, true);

preg_match_all('#<a href="(.*[mbw][kpe][4bv])" target="_blank" rel="nofollow" class="btn mx-auto my-4 w-max font-bold bg-success" style="(.*)">#', $bexyy, $links);

$read = ['ok'=>true, 'writer'=>"aminrngbr", 'channel'=>"@sourcetalar", 'result'=>['link'=>$links[1][0]]];

echo json_encode($read, 1000);

	}
	
	?>