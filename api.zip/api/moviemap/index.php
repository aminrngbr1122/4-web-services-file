<?php

/*

• Channel  » @sourcetalar «
• Writer  » @aminrngbr «

// ===== اگه مادرت برات محترمه منبع رو پاک نکن عزیزم ===== \\
*/
//=========================================

///Disable error reporting///
error_reporting(0);

///Set the program on Json///
header("Content-type: application/json");

///Getting search and typing values///
@$type = $_GET['type'];
@$s = $_GET['search'];

///Check typed value///
if(@$type == "search"){
	
///Remove blank spaces in the text///
$set = str_replace(" ","+",$s);

///Connecting to the Movie Map site and getting its information as Json///
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://www.movie-map.com/{$set}");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 6000);
$json = json_encode(curl_exec($ch));
$file = fopen("./header.txt", "w");
fwrite($file, $json);
fclose($file);
curl_close($ch);

///Extracting Json's information received from the site///
$array = json_decode($json);

///Extract all names of similar movies with regular expressions///
preg_match_all('/<a href="(.*)" (.*)>(.*)<\/a>/', $array, $data);

///Pouring all the names into a presentation///
for($i = 1; $i < count($data[3]); $i++){ 
 $name = $data[3][$i]; 
 $net = ['name'=>$name]; 
 $arry[] = $net; 
 }

///Sticking two presentations together///
	$exec = ['ok'=>true, 'writer'=>'aminrngbr', 'search'=>"{$s}", 'result'=>$arry];

///Creating the Json file and showing the names///
	echo json_encode($exec, 448);
	
}else{
echo "?type=search&search=batman";
}

/*

• Channel  » @sourcetalar «
• Writer  » @aminrngbr «

// ===== اگه مادرت برات محترمه منبع رو پاک نکن عزیزم ===== \\
*/
//=========================================

?>